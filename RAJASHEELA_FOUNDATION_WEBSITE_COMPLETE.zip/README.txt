RAJASHEELA FOUNDATION WEBSITE

Included:
- index.html — complete website content
- style.css — responsive sky-blue (#85a1ff) and white design with blur/scroll reveal animations
- script.js — mobile navigation, scroll animations, and client-side form validation
- logo.png — foundation logo

PREVIEW:
Extract this ZIP, then open index.html in Chrome.

GITHUB PAGES:
1. Open your repository: https://github.com/gthilaknadh055-oss/RAJASHEELA-FOUNDATION
2. Upload ALL FOUR files (index.html, style.css, script.js, logo.png) to the repository root.
3. Commit the changes.
4. Wait for GitHub Pages to publish the updated site.

IMPORTANT — APPLICATION SUBMISSIONS:
The form currently checks required fields in the browser only. It does NOT yet send or store applications. Connect a Google Apps Script / Google Sheets backend and test it before accepting applications online.

CONTACT:
9959711525 | 9010661852
rajasheela108@gmail.com
