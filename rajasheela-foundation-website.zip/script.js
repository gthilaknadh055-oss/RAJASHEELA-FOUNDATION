// REPLACE THIS WITH YOUR ACTUAL RAJASHEELA FOUNDATION UPI ID
const UPI_ID = "YOUR_UPI_ID@okaxis";
const PAYEE_NAME = "Rajasheela Foundation";

document.addEventListener("DOMContentLoaded", () => {
  const amountButtons = document.querySelectorAll(".amt-btn");
  const displayAmount = document.getElementById("displayAmount");
  const btnAmountText = document.getElementById("btnAmountText");
  const displayUpiId = document.getElementById("displayUpiId");
  const upiQrImage = document.getElementById("upiQrImage");

  const phonepeLink = document.getElementById("phonepeLink");
  const gpayLink = document.getElementById("gpayLink");
  const genericUpiLink = document.getElementById("genericUpiLink");

  const confirmPaymentBtn = document.getElementById("confirmPaymentBtn");
  const utrInput = document.getElementById("utrInput");
  const paymentMessage = document.getElementById("paymentMessage");
  const applicationForm = document.getElementById("applicationForm");
  const formMessage = document.getElementById("formMessage");

  let selectedAmount = 2500;
  displayUpiId.textContent = UPI_ID;

  function updatePaymentDetails(amount) {
    selectedAmount = amount;
    const formatted = Number(amount).toLocaleString("en-IN");
    displayAmount.textContent = `₹${formatted}`;
    btnAmountText.textContent = amount;

    // Standard NPCI UPI Intent URI
    const upiParams = `pa=${encodeURIComponent(UPI_ID)}&pn=${encodeURIComponent(PAYEE_NAME)}&am=${amount}&cu=INR&tn=${encodeURIComponent("Rajasheela Foundation Contribution")}`;
    const standardUpiUrl = `upi://pay?${upiParams}`;

    // App-specific deep links for mobile browsers
    phonepeLink.href = `phonepe://pay?${upiParams}`;
    gpayLink.href = `tez://upi/pay?${upiParams}`;
    genericUpiLink.href = standardUpiUrl;

    // Generate QR Code dynamically for the selected amount
    const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(standardUpiUrl)}`;
    upiQrImage.src = qrApiUrl;
  }

  // Handle amount button clicks
  amountButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      amountButtons.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      updatePaymentDetails(btn.dataset.amount);
    });
  });

  // Handle UTR confirmation
  confirmPaymentBtn.addEventListener("click", () => {
    const utr = utrInput.value.trim();
    if (!/^[0-9]{12}$/.test(utr)) {
      paymentMessage.style.color = "#b91c1c";
      paymentMessage.textContent = "Please enter a valid 12-digit numeric UTR / Transaction ID.";
      return;
    }
    paymentMessage.style.color = "#0f766e";
    paymentMessage.textContent = `Payment of ₹${Number(selectedAmount).toLocaleString("en-IN")} recorded with UTR ${utr}. Thank you!`;
  });

  // Basic form submission feedback (until Google Sheets integration is connected)
  applicationForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const photos = applicationForm.querySelector('input[name="passportPhotos"]').files;
    if (photos.length !== 2) {
      formMessage.style.color = "#b91c1c";
      formMessage.textContent = "Please select exactly two passport-size photographs.";
      return;
    }
    formMessage.style.color = "#0f766e";
    formMessage.textContent = "Application details verified! Please complete the payment section below.";
    document.getElementById("payment").scrollIntoView({ behavior: "smooth" });
  });

  // Initialize default ₹2,500 QR code on page load
  updatePaymentDetails(2500);
});
